﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;

namespace SharpHashSpeedTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = File.ReadAllText(
                Path.Combine(Path.GetDirectoryName(new Uri(
                    Assembly.GetEntryAssembly().CodeBase).LocalPath), 
                    @"en.txt")
                );

            DateTime start = DateTime.Now;
            uint hash = 0;
            for (int i=0; i<100; ++i)
                hash = HashBKDR(text);
            DateTime finish = DateTime.Now;

            Console.WriteLine("Hash = " + hash + "; Time = " + 
                (finish - start).TotalMilliseconds + " msec.");
        }

        private static uint HashBKDR(string str)
        {
            //{Note: this hash function is described in "The C Programming Language"
            //       by Brian Kernighan and Donald Ritchie, Prentice Hall}
            uint bitsInLongint = sizeof(uint) * 8;
            uint result = 0;
            for (int i = 0; i < str.Length; i++)
            {
                result = (result * (bitsInLongint - 1)) + str[i];
            }
            return result;
        }

    }
}
