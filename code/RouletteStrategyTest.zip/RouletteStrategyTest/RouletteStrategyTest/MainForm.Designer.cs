﻿namespace RouletteStrategyTest
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lStepNum = new System.Windows.Forms.Label();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.bStart = new System.Windows.Forms.Button();
			this.lMoney = new System.Windows.Forms.Label();
			this.bLog = new System.Windows.Forms.Button();
			this.bReset = new System.Windows.Forms.Button();
			this.nudInitialMoney = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.nudMinStake = new System.Windows.Forms.NumericUpDown();
			this.nudMaxStake = new System.Windows.Forms.NumericUpDown();
			((System.ComponentModel.ISupportInitialize)(this.nudInitialMoney)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nudMinStake)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nudMaxStake)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(15, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(42, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "Money:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(15, 38);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(32, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Step:";
			// 
			// lStepNum
			// 
			this.lStepNum.AutoSize = true;
			this.lStepNum.Location = new System.Drawing.Point(154, 38);
			this.lStepNum.Name = "lStepNum";
			this.lStepNum.Size = new System.Drawing.Size(13, 13);
			this.lStepNum.TabIndex = 9;
			this.lStepNum.Text = "0";
			// 
			// timer
			// 
			this.timer.Interval = 10;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// bStart
			// 
			this.bStart.Location = new System.Drawing.Point(316, 9);
			this.bStart.Name = "bStart";
			this.bStart.Size = new System.Drawing.Size(105, 23);
			this.bStart.TabIndex = 0;
			this.bStart.Text = "Start";
			this.bStart.UseVisualStyleBackColor = true;
			this.bStart.Click += new System.EventHandler(this.bStart_Click);
			// 
			// lMoney
			// 
			this.lMoney.AutoSize = true;
			this.lMoney.Location = new System.Drawing.Point(154, 14);
			this.lMoney.Name = "lMoney";
			this.lMoney.Size = new System.Drawing.Size(13, 13);
			this.lMoney.TabIndex = 7;
			this.lMoney.Text = "0";
			// 
			// bLog
			// 
			this.bLog.Location = new System.Drawing.Point(316, 38);
			this.bLog.Name = "bLog";
			this.bLog.Size = new System.Drawing.Size(105, 23);
			this.bLog.TabIndex = 1;
			this.bLog.Text = "Log to Clipboad";
			this.bLog.UseVisualStyleBackColor = true;
			this.bLog.Click += new System.EventHandler(this.bLog_Click);
			// 
			// bReset
			// 
			this.bReset.Location = new System.Drawing.Point(316, 70);
			this.bReset.Name = "bReset";
			this.bReset.Size = new System.Drawing.Size(104, 22);
			this.bReset.TabIndex = 2;
			this.bReset.Text = "Reset";
			this.bReset.UseVisualStyleBackColor = true;
			this.bReset.Click += new System.EventHandler(this.bReset_Click);
			// 
			// nudInitialMoney
			// 
			this.nudInitialMoney.Location = new System.Drawing.Point(157, 103);
			this.nudInitialMoney.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
			this.nudInitialMoney.Name = "nudInitialMoney";
			this.nudInitialMoney.Size = new System.Drawing.Size(120, 20);
			this.nudInitialMoney.TabIndex = 3;
			this.nudInitialMoney.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(25, 105);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(68, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Initial money:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(25, 130);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(74, 13);
			this.label4.TabIndex = 11;
			this.label4.Text = "Minimal stake:";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(25, 156);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(77, 13);
			this.label5.TabIndex = 12;
			this.label5.Text = "Maximal stake:";
			// 
			// nudMinStake
			// 
			this.nudMinStake.Location = new System.Drawing.Point(157, 128);
			this.nudMinStake.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
			this.nudMinStake.Name = "nudMinStake";
			this.nudMinStake.Size = new System.Drawing.Size(120, 20);
			this.nudMinStake.TabIndex = 4;
			this.nudMinStake.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// nudMaxStake
			// 
			this.nudMaxStake.Location = new System.Drawing.Point(157, 154);
			this.nudMaxStake.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
			this.nudMaxStake.Name = "nudMaxStake";
			this.nudMaxStake.Size = new System.Drawing.Size(120, 20);
			this.nudMaxStake.TabIndex = 5;
			this.nudMaxStake.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(434, 185);
			this.Controls.Add(this.nudMaxStake);
			this.Controls.Add(this.nudMinStake);
			this.Controls.Add(this.nudInitialMoney);
			this.Controls.Add(this.bReset);
			this.Controls.Add(this.bLog);
			this.Controls.Add(this.bStart);
			this.Controls.Add(this.lMoney);
			this.Controls.Add(this.lStepNum);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "MainForm";
			this.Text = "Roulette strategy testing";
			((System.ComponentModel.ISupportInitialize)(this.nudInitialMoney)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nudMinStake)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nudMaxStake)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lStepNum;
		private System.Windows.Forms.Timer timer;
		private System.Windows.Forms.Button bStart;
		private System.Windows.Forms.Label lMoney;
		private System.Windows.Forms.Button bLog;
		private System.Windows.Forms.Button bReset;
		private System.Windows.Forms.NumericUpDown nudInitialMoney;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown nudMinStake;
		private System.Windows.Forms.NumericUpDown nudMaxStake;
	}
}

