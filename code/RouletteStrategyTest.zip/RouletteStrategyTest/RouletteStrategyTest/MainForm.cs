﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RouletteStrategyTest
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
			InitValues();
		}

		decimal currentStake = 1;
		decimal currentMoney = 100;
		int currentStep = 0;
		bool evenStake = true;
		Random rnd = new Random();

		StringBuilder log = new StringBuilder();

		private void timer_Tick(object sender, EventArgs e)
		{
			int sector = rnd.Next(37);
			bool isWin = false;
			if (sector != 0)
			{
				if (evenStake == (sector % 2 == 0))
				{
					isWin = true;
				}
			}

			log.AppendLine("Stake on " + (evenStake ? "even" : "odd"));
			log.AppendLine("Sector: " + sector);
			log.AppendLine(isWin ? "+++Win!" : "---Loss.");
			log.AppendLine("Stake=" + currentStake);

			if (isWin)
			{
				currentMoney += currentStake;
				currentStake = nudMinStake.Value;
				evenStake = !evenStake;
			}
			else
			{
				currentMoney -= currentStake;
				currentStake *= 2;
				if (currentStake > nudMaxStake.Value)
					currentStake = nudMinStake.Value;
			}
			log.AppendLine("Money=" + currentMoney);
			log.AppendLine("***");
			currentStep++;
			DrawState();
			if (currentMoney < 0)
			{
				DisableTimer();
				MessageBox.Show(this, "Loss!!!");
			}
		}

		private void DrawState()
		{
			lMoney.Text = "" + currentMoney;
			lStepNum.Text = "" + currentStep;
		}

		private void bStart_Click(object sender, EventArgs e)
		{
			if (timer.Enabled)
			{
				DisableTimer();
			}
			else
			{
				bStart.Text = "Stop";
				timer.Enabled = true;
			}
		}

		private void DisableTimer()
		{
			timer.Enabled = false;
			bStart.Text = "Start";
		}

		private void bLog_Click(object sender, EventArgs e)
		{
			try
			{
				Clipboard.SetText(log.ToString());
			}
			catch { }
		}

		private void bReset_Click(object sender, EventArgs e)
		{
			InitValues();
		}

		private void InitValues()
		{
			currentMoney = nudInitialMoney.Value;
			currentStep = 0;
			currentStake = nudMinStake.Value;
			log.Length = 0;
			DrawState();
		}
	}
}
